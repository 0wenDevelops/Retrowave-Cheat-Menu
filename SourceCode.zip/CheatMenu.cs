using MelonLoader;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[assembly: MelonInfo(typeof(RetrowaveMod.CheatMenu), "Owen's Cheat Menu", "1.0.0", "Im_Owen")]
// Optionally set the MelonGame attribute to match the target game:
// [assembly: MelonGame("Rewindapp", "Retrowave")]

namespace RetrowaveMod
{
    public class CheatMenu : MelonMod
    {
        // ── Toggle key ──────────────────────────────────────────────────────────
        private const KeyCode TOGGLE_KEY = KeyCode.F1;

        // ── ObscuredPrefs methods ───────────────────────────────────────────────
        private static MethodInfo _obsSetInt;
        private static MethodInfo _obsGetInt;
        private static MethodInfo _obsSetFloat;

        // ── HR_ModApplier fields/properties (for upgrading cars) ───────────────
        private static Type      _modApplierType;
        private static FieldInfo _speedLevelField;
        private static FieldInfo _handlingLevelField;
        private static FieldInfo _brakeLevelField;
        private static FieldInfo _isSirenField;
        private static FieldInfo _isNOSField;
        private static FieldInfo _isTurboField;

        // property fallbacks
        private static PropertyInfo _speedLevelProp;
        private static PropertyInfo _handlingLevelProp;
        private static PropertyInfo _brakeLevelProp;
        private static PropertyInfo _isSirenProp;
        private static PropertyInfo _isNOSProp;
        private static PropertyInfo _isTurboProp;

        // ── HR_TrafficPooling (difficulty) ──────────────────────────────────────
        private static Type      _trafficPoolingType;
        private static FieldInfo _difficultyField;
        private static PropertyInfo _difficultyProp;

        // ── UI state ────────────────────────────────────────────────────────────
        private bool _showMenu = false;
        private Rect _windowRect = new Rect(20, 20, 420, 820);
        private Vector2 _scrollPos = Vector2.zero;
        private string _statusMsg = "Ready.";
        private float  _statusTimer = 0f;
        private int _wheelIndex = 0;

        // ── Notification ────────────────────────────────────────────────────────
        private void Status(string msg) { _statusMsg = msg; _statusTimer = 4f; LoggerInstance.Msg("[CheatMenu] " + msg); }

        // ── ObscuredPrefs helpers ───────────────────────────────────────────────
        private void ObsSetInt(string key, int value)
        {
            if (_obsSetInt != null)
            {
                try
                {
                    _obsSetInt.Invoke(null, new object[] { key, value });
                    LoggerInstance.Msg($"[CheatMenu] ObsSetInt('{key}', {value}) invoked.");
                    return;
                }
                catch (Exception ex) { LoggerInstance.Warning("[CheatMenu] ObsSetInt failed: " + ex.Message); }
            }
            else
            {
                LoggerInstance.Warning("[CheatMenu] ObsSetInt method not found.");
            }
        }
        private int ObsGetInt(string key, int def = 0)
        {
            if (_obsGetInt != null)
            {
                try
                {
                    var ret = (int)_obsGetInt.Invoke(null, new object[] { key, def });
                    LoggerInstance.Msg($"[CheatMenu] ObsGetInt('{key}') => {ret}");
                    return ret;
                }
                catch (Exception ex) { LoggerInstance.Warning("[CheatMenu] ObsGetInt failed: " + ex.Message); }
            }
            else
            {
                LoggerInstance.Warning("[CheatMenu] ObsGetInt method not found.");
            }
            return def;
        }

        // ── Reflect on startup ──────────────────────────────────────────────────
        public override void OnInitializeMelon()
        {
            LoggerInstance.Msg("[CheatMenu] Initializing reflection...");
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try { types = asm.GetTypes(); } catch { continue; }
                foreach (var type in types)
                {
                    if (type.Name == "ObscuredPrefs")
                    {
                        _obsSetInt   = type.GetMethod("SetInt",   BindingFlags.Static | BindingFlags.Public, null, new Type[] { typeof(string), typeof(int) }, null);
                        _obsGetInt   = type.GetMethod("GetInt",   BindingFlags.Static | BindingFlags.Public, null, new Type[] { typeof(string), typeof(int) }, null);
                        _obsSetFloat = type.GetMethod("SetFloat",  BindingFlags.Static | BindingFlags.Public, null, new Type[] { typeof(string), typeof(float) }, null);
                        LoggerInstance.Msg("[CheatMenu] Found ObscuredPrefs methods: SetInt=" + (_obsSetInt != null) + " GetInt=" + (_obsGetInt != null) + " SetFloat=" + (_obsSetFloat != null));
                    }
                    if (type.Name == "HR_ModApplier")
                    {
                        _modApplierType      = type;
                        _speedLevelField     = type.GetField("_speedLevel",     BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _handlingLevelField  = type.GetField("_handlingLevel",  BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _brakeLevelField     = type.GetField("_brakeLevel",     BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isSirenField        = type.GetField("isSirenPurchased",BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isNOSField          = type.GetField("isNOSPurchased",  BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isTurboField        = type.GetField("isTurboPurchased",BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                        // property fallbacks (common names)
                        _speedLevelProp      = type.GetProperty("speedLevel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _handlingLevelProp   = type.GetProperty("handlingLevel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _brakeLevelProp      = type.GetProperty("brakeLevel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isSirenProp         = type.GetProperty("isSirenPurchased", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isNOSProp           = type.GetProperty("isNOSPurchased", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _isTurboProp         = type.GetProperty("isTurboPurchased", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                        LoggerInstance.Msg("[CheatMenu] HR_ModApplier reflection: modApplierType=" + (_modApplierType != null)
                            + " speedField=" + (_speedLevelField != null) + " speedProp=" + (_speedLevelProp != null)
                            + " handlingField=" + (_handlingLevelField != null) + " handlingProp=" + (_handlingLevelProp != null)
                            + " brakeField=" + (_brakeLevelField != null) + " brakeProp=" + (_brakeLevelProp != null)
                            + " isSirenField=" + (_isSirenField != null) + " isSirenProp=" + (_isSirenProp != null));
                    }
                    if (type.Name == "HR_TrafficPooling")
                    {
                        _trafficPoolingType = type;
                        _difficultyField    = type.GetField("Difficulty", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        _difficultyProp     = type.GetProperty("Difficulty", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        LoggerInstance.Msg("[CheatMenu] HR_TrafficPooling reflection: type=" + (_trafficPoolingType != null) + " difficultyField=" + (_difficultyField != null) + " difficultyProp=" + (_difficultyProp != null));
                    }
                }
            }
            LoggerInstance.Msg("[CheatMenu] Reflection initialization complete. Press F1 to open.");
        }

        public override void OnUpdate()
        {
            // Toggle menu and log only once when toggled
            if (Input.GetKeyDown(TOGGLE_KEY))
            {
                _showMenu = !_showMenu;
                Status(_showMenu ? "Menu opened" : "Menu closed");
            }

            if (_statusTimer > 0f) _statusTimer -= Time.deltaTime;
        }

        public override void OnGUI()
        {
            try
            {
                if (!_showMenu) return;

                GUIStyle winStyle;
                try
                {
                    winStyle = (GUI.skin != null && GUI.skin.window != null) ? new GUIStyle(GUI.skin.window) : new GUIStyle();
                }
                catch
                {
                    winStyle = new GUIStyle();
                }

                winStyle.normal.background = MakeTex(1, 1, new Color(0.05f, 0.05f, 0.1f, 0.97f));
                winStyle.normal.textColor  = new Color(1f, 0.2f, 0.6f);
                winStyle.fontStyle         = FontStyle.Bold;
                winStyle.fontSize          = 14;

                _windowRect = GUI.Window(999, _windowRect, DrawWindow, "  ★ OWEN'S CHEAT MENU  [F1]", winStyle);

                // ensure window doesn't exceed screen bounds
                _windowRect.width  = Mathf.Clamp(_windowRect.width,  320, Screen.width - 40);
                _windowRect.height = Mathf.Clamp(_windowRect.height, 300, Screen.height - 40);
            }
            catch (Exception ex)
            {
                LoggerInstance.Error("[CheatMenu] OnGUI exception: " + ex);
                _showMenu = false;
            }
        }

        private void DrawWindow(int id)
        {
            try
            {
                GUIStyle labelStyle, headerStyle, btnStyle, statusStyle;
                try
                {
                    labelStyle = (GUI.skin != null && GUI.skin.label != null) ? new GUIStyle(GUI.skin.label) : new GUIStyle();
                    headerStyle = (GUI.skin != null && GUI.skin.label != null) ? new GUIStyle(GUI.skin.label) : new GUIStyle();
                    statusStyle = (GUI.skin != null && GUI.skin.label != null) ? new GUIStyle(GUI.skin.label) : new GUIStyle();
                }
                catch
                {
                    labelStyle = new GUIStyle();
                    headerStyle = new GUIStyle();
                    statusStyle = new GUIStyle();
                }

                labelStyle.normal.textColor = new Color(0.9f, 0.9f, 1f);
                labelStyle.fontSize = 12;

                headerStyle.normal.textColor = new Color(1f, 0.3f, 0.7f);
                headerStyle.fontStyle = FontStyle.Bold;
                headerStyle.fontSize = 12;

                btnStyle = new GUIStyle();
                btnStyle.normal.background = MakeTex(1,1,new Color(0.15f,0.05f,0.25f,1f));
                btnStyle.normal.textColor = new Color(1f,0.8f,1f);
                btnStyle.hover.background = MakeTex(1,1,new Color(0.4f,0.1f,0.7f,1f));
                btnStyle.hover.textColor = Color.white;
                btnStyle.active.background = MakeTex(1,1,new Color(0.6f,0.2f,1f,1f));
                btnStyle.active.textColor = Color.white;
                btnStyle.fontSize = 12;
                btnStyle.padding = new RectOffset(6,6,5,5);

                statusStyle.normal.textColor = new Color(0.4f,1f,0.6f);
                statusStyle.fontStyle = FontStyle.Italic;
                statusStyle.fontSize = 11;

                GUILayout.Space(4);

                // Hints
                GUILayout.Label("Hints:", headerStyle);
                GUILayout.Label("- Some cheats require the car customization screen to refresh.", labelStyle);
                GUILayout.Label("- To apply immediately: select the car in-game (open car UI) then use 'Apply to Selected'.", labelStyle);
                GUILayout.Label("- If changes don't appear, press 'Refresh UI' to attempt forcing the game's UI to update.", labelStyle);
                GUILayout.Label("- I (the developer) am not responsible for any crashes, bans, Resets, or other issues caused by using these cheats.", labelStyle);
                GUILayout.Label("- When you Install or use these cheats you are acknowledging that you understand the risks of cheats and accept them", labelStyle);
                GUILayout.Label("- Please read my github's page for the full disclaimer before use", labelStyle);
                GUILayout.Label("- 'No Crash' must be clicked while in a match (player handler active).", labelStyle);
                GUILayout.Space(6);

                // Wheel quick controls (scan / apply)
                GUILayout.Label("Wheel Tools:", headerStyle);
                GUILayout.BeginHorizontal();
                GUILayout.Label("Wheel index:", labelStyle, GUILayout.Width(90));
                string wheelStr = GUILayout.TextField(_wheelIndex.ToString(), GUILayout.Width(40));
                int parsed;
                if (int.TryParse(wheelStr, out parsed)) _wheelIndex = Mathf.Clamp(parsed, 0, 99);
                if (GUILayout.Button("Scan for wheel types", btnStyle)) { FindWheelTypes(); }
                if (GUILayout.Button("Apply wheel to selected", btnStyle)) { ApplyWheelToSelected(_wheelIndex); }
                GUILayout.EndHorizontal();
                GUILayout.Space(6);

                // Diagnostics + quick actions
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Run Diagnostics", btnStyle)) { RunDiagnostics(); }
                if (GUILayout.Button("Dump ModAppliers", btnStyle)) { DumpModAppliers(); }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Apply to Selected Car", btnStyle)) { ApplyToSelectedCar(); }
                if (GUILayout.Button("Refresh UI (force)", btnStyle)) { RefreshUI(); Status("RefreshUI requested"); }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Test Prefs (set/read)", btnStyle)) { ObsSetInt("CheatMenu_TestKey", 12345); int read = ObsGetInt("CheatMenu_TestKey", -1); Status("TestKey => " + read); }
                if (GUILayout.Button("Check Pref Keys", btnStyle)) { CheckPrefKeys(); }
                GUILayout.EndHorizontal();

                GUILayout.Space(6);

                // Status bar
                GUILayout.Label(_statusTimer > 0f ? "✓ " + _statusMsg : "Press F1 to close", statusStyle);
                GUILayout.Space(4);

                _scrollPos = GUILayout.BeginScrollView(_scrollPos, GUILayout.ExpandHeight(true));

                // ── MONEY ────────────────────────────────────────────────────────────
                GUILayout.Label("── MONEY ──────────────────────", headerStyle);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Set $999,999", btnStyle)) { ObsSetInt("Currency", 999999); Status("Currency set to 999,999"); }
                if (GUILayout.Button("Set $9,999,999", btnStyle)) { ObsSetInt("Currency", 9999999); Status("Currency set to 9,999,999!"); }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("+$10,000", btnStyle)) { int cur = ObsGetInt("Currency",0); ObsSetInt("Currency", cur+10000); Status("Added $10,000 → $" + (cur+10000)); }
                if (GUILayout.Button("Set CurrencyUp x99", btnStyle)) { ObsSetInt("CurrencyUp", 99); Status("CurrencyUp set to 99"); }
                GUILayout.EndHorizontal();
                GUILayout.Space(6);

                // ── CURRENT CAR UPGRADES ─────────────────────────────────────────────
                GUILayout.Label("── CURRENT CAR UPGRADES ───────", headerStyle);
                if (GUILayout.Button("Max Speed / Handling / Brake (All)", btnStyle)) { MaxUpgradesOnAllCars(); Status("Attempted to max upgrades."); }
                if (GUILayout.Button("Unlock NOS + Turbo + Siren (All)", btnStyle))   { UnlockAllSpecials(); Status("Attempted to unlock specials."); }
                if (GUILayout.Button("MAX EVERYTHING on all cars", btnStyle))
                {
                    MaxUpgradesOnAllCars();
                    UnlockAllSpecials();
                    Status("Attempted to MAX EVERYTHING on all cars.");
                }
                GUILayout.Space(6);

                // ── UNLOCK ALL CARS ──────────────────────────────────────────────────
                GUILayout.Label("── CARS ────────────────────────", headerStyle);
                if (GUILayout.Button("Unlock All Cars (1-27)", btnStyle))
                {
                    for (int i = 1; i <= 27; i++)
                        ObsSetInt("PlayerCar" + i + "Owned", 1);
                    Status("All 27 cars unlocked!");
                }
                if (GUILayout.Button("Unlock All Colors (all cars)", btnStyle))
                {
                    for (int car = 1; car <= 27; car++)
                        for (int col = 0; col <= 9; col++)
                            ObsSetInt("PlayerCar" + car + "(Clone)OwnedColor" + col, 1);
                    Status("All colors unlocked!");
                }
                if (GUILayout.Button("Unlock All Wheels", btnStyle))
                {
                    for (int i = 0; i <= 25; i++)
                        ObsSetInt("OwnedWheel" + i, 1);
                    Status("All wheels unlocked!");
                }
                GUILayout.Space(6);

                // ── VICTORIES ────────────────────────────────────────────────────────
                GUILayout.Label("── VICTORIES & STATS ───────────", headerStyle);
                if (GUILayout.Button("Set 99 Wins with Every Car", btnStyle))
                {
                    for (int i = 1; i <= 27; i++)
                        ObsSetInt("VictoryWithCar_" + i, 99);
                    Status("99 wins set for all cars!");
                }
                if (GUILayout.Button("Set Total Played = 999", btnStyle)) { ObsSetInt("TotalPlayedCount", 999); Status("TotalPlayedCount = 999"); }
                if (GUILayout.Button("Set Win Multiplier = 99", btnStyle)) { ObsSetInt("TotalWinMulti", 99); Status("TotalWinMulti = 99"); }
                GUILayout.Space(6);

                // ── DIFFICULTY ───────────────────────────────────────────────────────
                GUILayout.Label("── DIFFICULTY ──────────────────", headerStyle);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Peaceful", btnStyle)) { SetDifficulty(0); Status("Difficulty: Peaceful"); }
                if (GUILayout.Button("Easy",     btnStyle)) { SetDifficulty(1); Status("Difficulty: Easy"); }
                if (GUILayout.Button("Normal",   btnStyle)) { SetDifficulty(2); Status("Difficulty: Normal"); }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Hard",   btnStyle)) { SetDifficulty(3); Status("Difficulty: Hard"); }
                if (GUILayout.Button("MEGA",   btnStyle)) { SetDifficulty(4); Status("Difficulty: MEGA"); }
                GUILayout.EndHorizontal();
                GUILayout.Space(6);

                // ── GAMEPLAY CHEATS ──────────────────────────────────────────────────
                GUILayout.Label("── GAMEPLAY ────────────────────", headerStyle);
                if (GUILayout.Button("Infinite Time (set 9999)", btnStyle))   { SetPlayerTimeLeft(9999f); Status("Time set to 9999!"); }
                if (GUILayout.Button("No Crash (can't die)", btnStyle))        { SetCanCrash(false); Status("Crash disabled!"); }
                if (GUILayout.Button("Re-enable Crash", btnStyle))             { SetCanCrash(true); Status("Crash re-enabled."); }
                GUILayout.Space(6);

                // ── MISC ─────────────────────────────────────────────────────────────
                GUILayout.Label("── MISC ────────────────────────", headerStyle);
                if (GUILayout.Button("Disable Cheat Blocker", btnStyle))
                {
                    ObsSetInt("blockmul", 0);
                    ObsSetInt("FCS", 1);
                    Status("Cheat block cleared!");
                }
                if (GUILayout.Button("DO ALL CHEATS AT ONCE", btnStyle))
                {
                    ObsSetInt("Currency", 9999999);
                    ObsSetInt("CurrencyUp", 99);
                    for (int i = 1; i <= 27; i++) { ObsSetInt("PlayerCar" + i + "Owned", 1); ObsSetInt("VictoryWithCar_" + i, 99); }
                    for (int car = 1; car <= 27; car++)
                        for (int col = 0; col <= 9; col++)
                            ObsSetInt("PlayerCar" + car + "(Clone)OwnedColor" + col, 1);
                    for (int i = 0; i <= 25; i++) ObsSetInt("OwnedWheel" + i, 1);
                    ObsSetInt("TotalPlayedCount", 999);
                    ObsSetInt("TotalWinMulti", 99);
                    ObsSetInt("blockmul", 0);
                    MaxUpgradesOnAllCars();
                    UnlockAllSpecials();
                    Status("★ EVERYTHING UNLOCKED ★");
                }

                GUILayout.EndScrollView();
                try { GUI.DragWindow(new Rect(0, 0, _windowRect.width, 20)); } catch (Exception) { }
            }
            catch (Exception ex)
            {
                LoggerInstance.Error("[CheatMenu] DrawWindow exception: " + ex);
            }
        }

        // ── Diagnostics & helpers ──────────────────────────────────────────────

        private void RunDiagnostics()
        {
            LoggerInstance.Msg("[CheatMenu][DIAG] Running diagnostics...");
            LoggerInstance.Msg("[CheatMenu][DIAG] obsSetInt=" + (_obsSetInt != null) + " obsGetInt=" + (_obsGetInt != null) + " obsSetFloat=" + (_obsSetFloat != null));
            LoggerInstance.Msg("[CheatMenu][DIAG] modApplierType=" + (_modApplierType != null));
            if (_modApplierType != null)
            {
                LoggerInstance.Msg("[CheatMenu][DIAG] speedField=" + (_speedLevelField != null) + " speedProp=" + (_speedLevelProp != null));
                LoggerInstance.Msg("[CheatMenu][DIAG] handlingField=" + (_handlingLevelField != null) + " handlingProp=" + (_handlingLevelProp != null));
                LoggerInstance.Msg("[CheatMenu][DIAG] brakeField=" + (_brakeLevelField != null) + " brakeProp=" + (_brakeLevelProp != null));
                LoggerInstance.Msg("[CheatMenu][DIAG] isSirenField=" + (_isSirenField != null) + " isSirenProp=" + (_isSirenProp != null));
                LoggerInstance.Msg("[CheatMenu][DIAG] isNOSField=" + (_isNOSField != null) + " isNOSProp=" + (_isNOSProp != null));
                LoggerInstance.Msg("[CheatMenu][DIAG] isTurboField=" + (_isTurboField != null) + " isTurboProp=" + (_isTurboProp != null));
            }
            LoggerInstance.Msg("[CheatMenu][DIAG] trafficPoolingType=" + (_trafficPoolingType != null) + " difficultyField=" + (_difficultyField != null) + " difficultyProp=" + (_difficultyProp != null));
        }

        private object GetMemberValue(object instance, FieldInfo field, PropertyInfo prop)
        {
            try
            {
                if (field != null) return field.GetValue(instance);
                if (prop != null && prop.CanRead) return prop.GetValue(instance, null);
            }
            catch (Exception ex) { LoggerInstance.Warning("[CheatMenu] GetMemberValue failed: " + ex.Message); }
            return null;
        }

        private void DumpModAppliers()
        {
            if (_modApplierType == null)
            {
                LoggerInstance.Warning("[CheatMenu][DIAG] _modApplierType is null.");
                return;
            }

            var instances = UnityEngine.Object.FindObjectsOfType(_modApplierType);
            LoggerInstance.Msg($"[CheatMenu][DIAG] Found {instances.Length} HR_ModApplier instances.");
            int idx = 0;
            foreach (var inst in instances)
            {
                idx++;
                string objName = "(non-monobehaviour)";
                var mb = inst as MonoBehaviour;
                if (mb != null) objName = mb.gameObject.name;

                object speedVal = GetMemberValue(inst, _speedLevelField, _speedLevelProp);
                object handlingVal = GetMemberValue(inst, _handlingLevelField, _handlingLevelProp);
                object brakeVal = GetMemberValue(inst, _brakeLevelField, _brakeLevelProp);
                object isSirenVal = GetMemberValue(inst, _isSirenField, _isSirenProp);
                object isNOSVal = GetMemberValue(inst, _isNOSField, _isNOSProp);
                object isTurboVal = GetMemberValue(inst, _isTurboField, _isTurboProp);

                LoggerInstance.Msg($"[CheatMenu][DIAG] #{idx}: {objName} ({inst.GetType().Name}) -> speed={speedVal ?? "null"}, handling={handlingVal ?? "null"}, brake={brakeVal ?? "null"}, siren={isSirenVal ?? "null"}, NOS={isNOSVal ?? "null"}, turbo={isTurboVal ?? "null"}");
            }
        }

        private void CheckPrefKeys()
        {
            LoggerInstance.Msg("[CheatMenu][DIAG] Checking known preference keys...");

            // basic keys
            string[] basicKeys = new string[] { "Currency", "CurrencyUp", "TotalPlayedCount", "TotalWinMulti", "blockmul", "FCS" };
            foreach (var k in basicKeys)
                LoggerInstance.Msg($"[CheatMenu][DIAG] Pref {k} = {ObsGetInt(k, -99999)}");

            // victory with cars
            for (int i = 1; i <= 27; i++)
            {
                LoggerInstance.Msg($"[CheatMenu][DIAG] VictoryWithCar_{i} = {ObsGetInt("VictoryWithCar_" + i, -99999)}");
                LoggerInstance.Msg($"[CheatMenu][DIAG] PlayerCar{i}Owned = {ObsGetInt("PlayerCar" + i + "Owned", -99999)}");
            }

            // colors per car (first cars only)
            for (int car = 1; car <= 5; car++)
            {
                for (int col = 0; col <= 9; col++)
                    LoggerInstance.Msg($"[CheatMenu][DIAG] PlayerCar{car}(Clone)OwnedColor{col} = {ObsGetInt($"PlayerCar{car}(Clone)OwnedColor{col}", -99999)}");
            }

            // wheels
            for (int i = 0; i <= 25; i++)
                LoggerInstance.Msg($"[CheatMenu][DIAG] OwnedWheel{i} = {ObsGetInt("OwnedWheel" + i, -99999)}");
        }

        // ── Verify helpers used by later operations ─────────────────────────────
        private bool ObsSetIntVerify(string key, int value)
        {
            try
            {
                ObsSetInt(key, value);
                int read = ObsGetInt(key, int.MinValue);
                bool ok = read == value;
                LoggerInstance.Msg($"[CheatMenu][VERIFY] Pref '{key}' => set {value}, read {read}, ok={ok}");
                return ok;
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning("[CheatMenu][VERIFY] ObsSetIntVerify failed: " + ex.Message);
                return false;
            }
        }

        private bool SetMemberValue(object instance, FieldInfo field, PropertyInfo prop, object value)
        {
            try
            {
                if (field != null)
                {
                    field.SetValue(instance, Convert.ChangeType(value, field.FieldType));
                    return true;
                }
                if (prop != null && prop.CanWrite)
                {
                    prop.SetValue(instance, Convert.ChangeType(value, prop.PropertyType), null);
                    return true;
                }
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning("[CheatMenu] SetMemberValue failed: " + ex.Message);
            }
            return false;
        }

        private bool SetAndVerifyMember(object instance, FieldInfo field, PropertyInfo prop, object value)
        {
            try
            {
                bool setOk = SetMemberValue(instance, field, prop, value);
                object read = GetMemberValue(instance, field, prop);

                if (read != null && value != null)
                {
                    try
                    {
                        if (read is IConvertible && value is IConvertible)
                        {
                            var tRead = Convert.ToDouble(read);
                            var tVal  = Convert.ToDouble(value);
                            bool ok = Math.Abs(tRead - tVal) < 0.0001;
                            LoggerInstance.Msg($"[CheatMenu][VERIFY] Member set: setOk={setOk}, read={tRead}, expected={tVal}, ok={ok}");
                            return ok;
                        }
                    }
                    catch { /* fall back */ }
                }

                bool eq = (read == null && value == null) || (read != null && read.Equals(value));
                LoggerInstance.Msg($"[CheatMenu][VERIFY] Member set: setOk={setOk}, read={(read??"null")}, expected={(value??"null")}, ok={eq}");
                return setOk && eq;
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning("[CheatMenu][VERIFY] SetAndVerifyMember failed: " + ex.Message);
                return false;
            }
        }

        private bool InvokeInstanceMethod(object instance, string methodName)
        {
            try
            {
                var mi = instance.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (mi != null)
                {
                    mi.Invoke(instance, null);
                    LoggerInstance.Msg($"[CheatMenu] Invoked {methodName} on {instance.GetType().Name}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning($"[CheatMenu] Invoke {methodName} failed: {ex.Message}");
            }
            return false;
        }

        // ── Cheat implementations (robust) ─────────────────────────────────────

        private void MaxUpgradesOnAllCars()
        {
            if (_modApplierType == null)
            {
                LoggerInstance.Warning("[CheatMenu] MaxUpgradesOnAllCars: _modApplierType is null.");
                Status("MaxUpgrades failed: mod type not found");
                return;
            }

            try
            {
                var instances = UnityEngine.Object.FindObjectsOfType(_modApplierType);
                int attempted = 0;
                int succeeded = 0;
                foreach (var inst in instances)
                {
                    if (inst == null) continue;
                    attempted++;

                    bool speedOk = SetAndVerifyMember(inst, _speedLevelField, _speedLevelProp, 5);
                    bool handlingOk = SetAndVerifyMember(inst, _handlingLevelField, _handlingLevelProp, 5);
                    bool brakeOk = SetAndVerifyMember(inst, _brakeLevelField, _brakeLevelProp, 5);

                    if (speedOk || handlingOk || brakeOk)
                    {
                        succeeded++;
                        if (!InvokeInstanceMethod(inst, "UpdateStats"))
                            InvokeInstanceMethod(inst, "Update"); // fallback
                    }

                    var mb = inst as MonoBehaviour;
                    if (mb != null)
                    {
                        try
                        {
                            string carName = mb.gameObject.name.Replace("(Clone)", "").Trim();
                            bool pref1 = ObsSetIntVerify(carName + "SpeedLevel", 5);
                            bool pref2 = ObsSetIntVerify(carName + "HandlingLevel", 5);
                            bool pref3 = ObsSetIntVerify(carName + "BrakeLevel", 5);
                            LoggerInstance.Msg($"[CheatMenu] Pref verify for {carName}: speed={pref1}, handling={pref2}, brake={pref3}");
                        }
                        catch (Exception ex) { LoggerInstance.Warning("[CheatMenu] Saving prefs failed: " + ex.Message); }
                    }
                }

                LoggerInstance.Msg($"[CheatMenu] MaxUpgradesOnAllCars: attempted={attempted}, succeeded={succeeded}");
                Status($"MaxUpgrades: {succeeded}/{attempted} updated");
            }
            catch (Exception ex) { LoggerInstance.Error("MaxUpgrades error: " + ex.Message); Status("MaxUpgrades failed (see log)"); }
        }

        private void UnlockAllSpecials()
        {
            if (_modApplierType == null)
            {
                LoggerInstance.Warning("[CheatMenu] UnlockAllSpecials: _modApplierType is null.");
                Status("UnlockSpecials failed: mod type not found");
                return;
            }

            try
            {
                var instances = UnityEngine.Object.FindObjectsOfType(_modApplierType);
                int attempted = 0;
                int succeeded = 0;
                foreach (var inst in instances)
                {
                    if (inst == null) continue;
                    attempted++;

                    bool sirenOk = SetAndVerifyMember(inst, _isSirenField, _isSirenProp, true);
                    bool nosOk = SetAndVerifyMember(inst, _isNOSField, _isNOSProp, true);
                    bool turboOk = SetAndVerifyMember(inst, _isTurboField, _isTurboProp, true);

                    if (sirenOk || nosOk || turboOk)
                    {
                        succeeded++;
                        if (!InvokeInstanceMethod(inst, "CreateSiren"))
                            InvokeInstanceMethod(inst, "UpdateStats");
                    }
                }
                // Also persist prefs and verify
                int prefSetCount = 0;
                for (int i = 1; i <= 27; i++)
                {
                    bool p1 = ObsSetIntVerify("PlayerCar" + i + "NOS", 1);
                    bool p2 = ObsSetIntVerify("PlayerCar" + i + "Turbo", 1);
                    bool p3 = ObsSetIntVerify("PlayerCar" + i + "Siren", 1);
                    if (p1 && p2 && p3) prefSetCount++;
                }

                LoggerInstance.Msg($"[CheatMenu] UnlockAllSpecials: attempted={attempted}, succeeded={succeeded}, prefsUpdated={prefSetCount}/27");
                Status($"UnlockSpecials: {succeeded}/{attempted} updated, prefs: {prefSetCount}/27");
            }
            catch (Exception ex) { LoggerInstance.Error("UnlockSpecials error: " + ex.Message); Status("UnlockSpecials failed (see log)"); }
        }

        // Apply changes to the first found HR_ModApplier (useful when the game has a single active selected car)
        private void ApplyToSelectedCar()
        {
            if (_modApplierType == null)
            {
                Status("Selected apply failed: mod type not found");
                return;
            }

            try
            {
                var instances = UnityEngine.Object.FindObjectsOfType(_modApplierType);
                if (instances == null || instances.Length == 0)
                {
                    Status("No HR_ModApplier instances found");
                    return;
                }

                var inst = instances[0];
                var mb = inst as MonoBehaviour;
                string name = mb != null ? mb.gameObject.name : inst.GetType().Name;

                bool s1 = SetAndVerifyMember(inst, _speedLevelField, _speedLevelProp, 5);
                bool s2 = SetAndVerifyMember(inst, _handlingLevelField, _handlingLevelProp, 5);
                bool s3 = SetAndVerifyMember(inst, _brakeLevelField, _brakeLevelProp, 5);
                bool sno = SetAndVerifyMember(inst, _isNOSField, _isNOSProp, true);
                bool stu = SetAndVerifyMember(inst, _isTurboField, _isTurboProp, true);
                bool ssr = SetAndVerifyMember(inst, _isSirenField, _isSirenProp, true);

                if (!InvokeInstanceMethod(inst, "UpdateStats"))
                    InvokeInstanceMethod(inst, "Update");

                Status($"Applied to {name}: upgrades ok={(s1||s2||s3)}, specials ok={(sno||stu||ssr)}");
                LoggerInstance.Msg($"[CheatMenu] ApplyToSelectedCar: {name} -> upgrades: {s1},{s2},{s3}, specials: {sno},{stu},{ssr}");
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning("[CheatMenu] ApplyToSelectedCar failed: " + ex.Message);
                Status("ApplyToSelectedCar failed (see log)");
            }
        }

        // Attempt to force UI/handlers to refresh - tries common handler types and methods
        private void RefreshUI()
        {
            int invoked = 0;
            try
            {
                // Try HR_ModHandler, HR_MainMenuHandler and any HR_ModApplier
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    Type[] types;
                    try { types = asm.GetTypes(); } catch { continue; }
                    foreach (var type in types)
                    {
                        if (type.Name == "HR_ModHandler" || type.Name == "HR_MainMenuHandler" || type.Name == "HR_ModApplier")
                        {
                            var instances = UnityEngine.Object.FindObjectsOfType(type);
                            foreach (var inst in instances)
                            {
                                if (inst == null) continue;
                                // Common methods to force UI/state refresh
                                string[] tryMethods = new string[] { "UpdateStats", "CreateSiren", "CreateCars", "EnableMenu", "Update", "SetDirty", "CheckButtonColors", "RefreshUI" };
                                foreach (var m in tryMethods)
                                {
                                    if (InvokeInstanceMethod(inst, m)) invoked++;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { LoggerInstance.Warning("[CheatMenu] RefreshUI error: " + ex.Message); }

            LoggerInstance.Msg("[CheatMenu] RefreshUI attempted, invoked methods: " + invoked);
            Status("RefreshUI attempted, invoked: " + invoked);
        }

        private void SetDifficulty(int level)
        {
            ObsSetInt("Difficulty", level);
            if (_trafficPoolingType == null)
            {
                LoggerInstance.Warning("[CheatMenu] SetDifficulty: _trafficPoolingType is null.");
                return;
            }
            try
            {
                var instances = UnityEngine.Object.FindObjectsOfType(_trafficPoolingType);
                int modified = 0;
                foreach (var inst in instances)
                {
                    if (inst == null) continue;
                    bool ok = false;
                    if (_difficultyField != null)
                    {
                        _difficultyField.SetValue(inst, level);
                        ok = true;
                    }
                    else if (_difficultyProp != null && _difficultyProp.CanWrite)
                    {
                        _difficultyProp.SetValue(inst, level, null);
                        ok = true;
                    }
                    if (ok) modified++;
                }
                LoggerInstance.Msg("[CheatMenu] SetDifficulty: modified instances = " + modified);
                Status("Difficulty set to " + level);
            }
            catch { }
        }

        private void SetPlayerTimeLeft(float time)
        {
            try
            {
                var handlers = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>();
                foreach (var mb in handlers)
                {
                    if (mb == null || mb.GetType().Name != "HR_PlayerHandler") continue;
                    var f = mb.GetType().GetField("timeLeft", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (f != null) f.SetValue(mb, time);
                    else
                    {
                        var p = mb.GetType().GetProperty("timeLeft", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        if (p != null && p.CanWrite) p.SetValue(mb, time, null);
                    }
                }
                LoggerInstance.Msg("[CheatMenu] SetPlayerTimeLeft attempted.");
            }
            catch { }
        }

        // --- Replace existing SetCanCrash(...) with this improved version ---
        private void SetCanCrash(bool canCrash)
        {
            int modified = 0;
            try
            {
                var handlers = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>();
                foreach (var mb in handlers)
                {
                    if (mb == null) continue;
                    // Match by type name to avoid requiring compile-time type
                    if (mb.GetType().Name != "HR_PlayerHandler") continue;

                    var type = mb.GetType();
                    var f = type.GetField("canCrash", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (f != null)
                    {
                        f.SetValue(mb, canCrash);
                        // verify
                        var read = f.GetValue(mb);
                        if (read is bool && (bool)read == canCrash) modified++;
                        continue;
                    }

                    var p = type.GetProperty("canCrash", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (p != null && p.CanWrite)
                    {
                        p.SetValue(mb, canCrash, null);
                        // verify
                        object read = null;
                        try { if (p.CanRead) read = p.GetValue(mb, null); } catch { read = null; }
                        if (read is bool && (bool)read == canCrash) modified++;
                    }
                }

                if (modified > 0)
                {
                    LoggerInstance.Msg("[CheatMenu] SetCanCrash attempted, modified instances: " + modified);
                    Status(canCrash ? "Crash re-enabled." : "Crash disabled!");
                }
                else
                {
                    LoggerInstance.Warning("[CheatMenu] SetCanCrash: no HR_PlayerHandler instances found. Must be used during a match.");
                    Status("No HR_PlayerHandler found — use while in a match");
                }
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning("SetCanCrash error: " + ex.Message);
                Status("SetCanCrash failed (see log)");
            }
        }
        // --- end replacement ---

        // ── Texture helper ──────────────────────────────────────────────────────
        private static Texture2D MakeTex(int w, int h, Color col)
        {
            var tex = new Texture2D(w, h);
            var pixels = new Color[w * h];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = col;
            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }

        // Wheel diagnostics and quick-apply helpers - add inside CheatMenu class

        private void FindWheelTypes()
        {
            LoggerInstance.Msg("[CheatMenu][WHEEL] Scanning assemblies for 'wheel' types/members...");
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try { types = asm.GetTypes(); } catch { continue; }
                foreach (var type in types)
                {
                    string tname = type.FullName ?? type.Name;
                    bool nameHas = type.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0;
                    var fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    var props  = type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    var methods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                    bool membersMatch = false;
                    foreach (var f in fields) if (f.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0) membersMatch = true;
                    foreach (var p in props)  if (p.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0) membersMatch = true;
                    foreach (var m in methods) if (m.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0) membersMatch = true;

                    if (!nameHas && !membersMatch) continue;

                    // Log type summary
                    LoggerInstance.Msg($"[CheatMenu][WHEEL] Type: {tname} (nameHas={nameHas}, membersMatch={membersMatch})");
                    foreach (var f in fields)
                        if (f.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0)
                            LoggerInstance.Msg($"[CheatMenu][WHEEL]   Field: {f.Name} : {f.FieldType.Name}");
                    foreach (var p in props)
                        if (p.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0)
                            LoggerInstance.Msg($"[CheatMenu][WHEEL]   Prop:  {p.Name} : {p.PropertyType.Name}");
                    foreach (var m in methods)
                        if (m.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0)
                            LoggerInstance.Msg($"[CheatMenu][WHEEL]   Method:{m.Name} (params={m.GetParameters().Length})");

                    // count live instances and sample values for wheel-like members
                    try
                    {
                        var instances = UnityEngine.Object.FindObjectsOfType(type);
                        LoggerInstance.Msg($"[CheatMenu][WHEEL]   Live instances: {instances.Length}");
                        int idx = 0;
                        foreach (var inst in instances)
                        {
                            idx++;
                            string instName = (inst as MonoBehaviour)?.gameObject.name ?? type.Name;
                            LoggerInstance.Msg($"[CheatMenu][WHEEL]   Instance #{idx}: {instName}");
                            foreach (var f in fields)
                            {
                                if (f.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0)
                                {
                                    object val = null;
                                    try { val = f.GetValue(inst); } catch { val = "(read fail)"; }
                                    LoggerInstance.Msg($"[CheatMenu][WHEEL]     Field {f.Name} = {val}");
                                }
                            }
                            foreach (var p in props)
                            {
                                if (p.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0)
                                {
                                    object val = null;
                                    try { if (p.CanRead) val = p.GetValue(inst, null); else val = "(no getter)"; } catch { val = "(read fail)"; }
                                    LoggerInstance.Msg($"[CheatMenu][WHEEL]     Prop  {p.Name} = {val}");
                                }
                            }
                        }
                    }
                    catch (Exception ex) { LoggerInstance.Warning("[CheatMenu][WHEEL] Instance query failed: " + ex.Message); }
                }
            }
            Status("Wheel scan complete (check log).");
        }

        private void ApplyWheelToSelected(int wheelIndex)
        {
            LoggerInstance.Msg($"[CheatMenu][WHEEL] Trying to apply wheel index {wheelIndex} to first matching instance...");
            int applied = 0;
            try
            {
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    Type[] types;
                    try { types = asm.GetTypes(); } catch { continue; }
                    foreach (var type in types)
                    {
                        var fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        var props  = type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                        bool hasWheelMember = false;
                        foreach (var f in fields)
                        {
                            if (f.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                (f.FieldType == typeof(int) || f.FieldType == typeof(short) || f.FieldType == typeof(byte)))
                            { hasWheelMember = true; break; }
                        }

                        if (!hasWheelMember)
                        {
                            foreach (var p in props)
                            {
                                if (p.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                    (p.PropertyType == typeof(int) || p.PropertyType == typeof(short) || p.PropertyType == typeof(byte)))
                                { hasWheelMember = true; break; }
                            }
                        }

                        if (!hasWheelMember) continue;

                        var instances = UnityEngine.Object.FindObjectsOfType(type);
                        foreach (var inst in instances)
                        {
                            if (inst == null) continue;
                            bool anySet = false;

                            foreach (var f in fields)
                            {
                                if (f.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                    (f.FieldType == typeof(int) || f.FieldType == typeof(short) || f.FieldType == typeof(byte)))
                                {
                                    try
                                    {
                                        object converted = Convert.ChangeType(wheelIndex, f.FieldType);
                                        f.SetValue(inst, converted);
                                        LoggerInstance.Msg($"[CheatMenu][WHEEL] Set field {type.Name}.{f.Name} = {converted}");
                                        anySet = true;
                                    }
                                    catch (Exception ex) { LoggerInstance.Warning($"[CheatMenu][WHEEL] Failed set {f.Name}: {ex.Message}"); }
                                }
                            }

                            foreach (var p in props)
                            {
                                if (p.Name.IndexOf("wheel", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                    p.CanWrite &&
                                    (p.PropertyType == typeof(int) || p.PropertyType == typeof(short) || p.PropertyType == typeof(byte)))
                                {
                                    try
                                    {
                                        object converted = Convert.ChangeType(wheelIndex, p.PropertyType);
                                        p.SetValue(inst, converted, null);
                                        LoggerInstance.Msg($"[CheatMenu][WHEEL] Set prop  {type.Name}.{p.Name} = {converted}");
                                        anySet = true;
                                    }
                                    catch (Exception ex) { LoggerInstance.Warning($"[CheatMenu][WHEEL] Failed set {p.Name}: {ex.Message}"); }
                                }
                            }

                            if (anySet)
                            {
                                // try common refresh methods
                                string[] tryMethods = new string[] { "ApplyWheel", "UpdateWheels", "CreateWheels", "UpdateStats", "Update", "RefreshUI", "Refresh" };
                                foreach (var m in tryMethods) InvokeInstanceMethod(inst, m);

                                // log selectedWheel if present
                                try
                                {
                                    var selField = inst.GetType().GetField("selectedWheel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                    if (selField != null)
                                    {
                                        var selVal = selField.GetValue(inst);
                                        LoggerInstance.Msg($"[CheatMenu][WHEEL] selectedWheel field value = {(selVal == null ? "null" : selVal.ToString())}");
                                    }
                                }
                                catch (Exception ex) { LoggerInstance.Warning($"[CheatMenu][WHEEL] selectedWheel read failed: {ex.Message}"); }

                                // Try explicit ChangeWheels overloads on the modified instance
                                try
                                {
                                    var methods = inst.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                    foreach (var mi in methods)
                                    {
                                        if (mi.Name != "ChangeWheels") continue;
                                        var ps = mi.GetParameters();
                                        try
                                        {
                                            if (ps.Length == 0)
                                            {
                                                mi.Invoke(inst, null);
                                                LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ChangeWheels() on {inst.GetType().Name}");
                                                break;
                                            }
                                            if (ps.Length == 1 && ps[0].ParameterType == typeof(int))
                                            {
                                                mi.Invoke(inst, new object[] { wheelIndex });
                                                LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ChangeWheels(int) on {inst.GetType().Name}");
                                                break;
                                            }
                                            if (ps.Length == 2 && ps[0].ParameterType == typeof(int) && ps[1].ParameterType == typeof(int))
                                            {
                                                mi.Invoke(inst, new object[] { wheelIndex, -1 });
                                                LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ChangeWheels(int,int) on {inst.GetType().Name}");
                                                break;
                                            }
                                            if (ps.Length == 1 && ps[0].ParameterType == typeof(UnityEngine.GameObject))
                                            {
                                                // try passing selectedWheel if we can read it, otherwise null
                                                object arg = null;
                                                var selField = inst.GetType().GetField("selectedWheel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                                if (selField != null) arg = selField.GetValue(inst);
                                                mi.Invoke(inst, new object[] { arg });
                                                LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ChangeWheels(GameObject) on {inst.GetType().Name}");
                                                break;
                                            }
                                            if (ps.Length == 2 && ps[0].ParameterType == typeof(int) && ps[1].ParameterType == typeof(UnityEngine.GameObject))
                                            {
                                                object arg = null;
                                                var selField = inst.GetType().GetField("selectedWheel", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                                if (selField != null) arg = selField.GetValue(inst);
                                                mi.Invoke(inst, new object[] { wheelIndex, arg });
                                                LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ChangeWheels(int,GameObject) on {inst.GetType().Name}");
                                                break;
                                            }
                                        }
                                        catch (Exception ex) { LoggerInstance.Warning($"[CheatMenu][WHEEL] ChangeWheels invoke failed on {inst.GetType().Name}: {ex.Message}"); }
                                    }
                                }
                                catch { /* non-fatal */ }

                                // If that didn't visually update, try calling ChangeWheels on any ModHandler-like instances (HR_ModHandler)
                                try
                                {
                                    foreach (var asm2 in AppDomain.CurrentDomain.GetAssemblies())
                                    {
                                        Type[] types2;
                                        try { types2 = asm2.GetTypes(); } catch { continue; }
                                        foreach (var t2 in types2)
                                        {
                                            // case-insensitive match without using StringComparison overload on Contains
                                            if (t2.Name.IndexOf("ModHandler", StringComparison.OrdinalIgnoreCase) < 0) continue;

                                            var instances2 = UnityEngine.Object.FindObjectsOfType(t2);
                                            foreach (var h2 in instances2)
                                            {
                                                if (h2 == null) continue;
                                                try
                                                {
                                                    // prefer ChangeWheels(int) on handler
                                                    var mi = t2.GetMethod("ChangeWheels", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[] { typeof(int) }, null);
                                                    if (mi != null)
                                                    {
                                                        mi.Invoke(h2, new object[] { wheelIndex });
                                                        LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ModHandler.ChangeWheels(int) on {t2.Name}");
                                                        continue;
                                                    }

                                                    // fallback: any ChangeWheels overload
                                                    var methods2 = t2.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                                    foreach (var m2 in methods2)
                                                    {
                                                        if (m2.Name != "ChangeWheels") continue;
                                                        try
                                                        {
                                                            int pcount = m2.GetParameters().Length;
                                                            object[] args = pcount == 0 ? null : new object[] { wheelIndex };
                                                            m2.Invoke(h2, args);
                                                            LoggerInstance.Msg($"[CheatMenu][WHEEL] Invoked ModHandler.ChangeWheels on {t2.Name}");
                                                            break;
                                                        }
                                                        catch { /* try next */ }
                                                    }
                                                }
                                                catch (Exception ex) { LoggerInstance.Warning($"[CheatMenu][WHEEL] ModHandler invoke failed: {ex.Message}"); }
                                            }
                                        }
                                    }
                                }
                                catch { /* non-fatal */ }

                                applied++;
                                Status($"Tried apply wheel {wheelIndex} on {type.Name} (check log).");
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { LoggerInstance.Warning("[CheatMenu][WHEEL] ApplyWheelToSelected failed: " + ex.Message); }

    if (applied == 0) Status("No wheel field found to set (run 'FindWheelTypes')");
}
        // Add two small UI hooks: call these from the menu (e.g. new buttons)
        // - FindWheelTypes()
        // - ApplyWheelToSelected(<index>) e.g. 0..25 depending on the game's wheel count
    }
}
